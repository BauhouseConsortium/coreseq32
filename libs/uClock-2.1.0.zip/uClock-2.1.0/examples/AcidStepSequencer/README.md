# TB303 Step Sequencer engine clone

With some user interface changes for cheap construction of a functional TB303 engine we present you the interface:

![Image of uMODULAR ctrl16 pcb top view](https://raw.githubusercontent.com/midilab/uClock/development/examples/AcidStepSequencer/acid_step_sequencer-protoboard-v001.png)

## Interface from left to rigth

POT1: Octave
POT2: Note
POT3: Sequence Length
POT4: Sequencer BPM Tempo

Button1: Prev Step
Button2: Next Step
Button3: Rest
Button4: Glide
Button5: Accent
Buttons6: Play/Stop